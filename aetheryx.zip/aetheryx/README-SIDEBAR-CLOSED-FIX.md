# ÆTHERYX — True Closed Sidebar Fix

## Change
The desktop sidebar now has two clear states:

- **Open:** the complete ÆTHERYX sidebar is visible.
- **Closed:** the sidebar becomes zero-width and completely disappears. Only the circular expand arrow remains visible.

No icon-only boxes, navigation cards, avatar box, text-size control, or empty sidebar space remains when closed.

## Behavior
- Click the arrow to close/open the sidebar.
- The state is remembered with localStorage.
- Main content expands to the full viewport when the sidebar is closed.
- The sidebar remains fixed while page content scrolls.
- Mobile sidebar behavior is unchanged.

## Validation
- JavaScript syntax check: passed
- Backend PHP syntax check: 0 errors
- Database/schema: unchanged
