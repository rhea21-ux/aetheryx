ÆTHERYX — change notes

UI
- Dashboard and Inventory share assets/css/aetheryx-ui.css (solid colors, no gradients).
- Fixed sidebar on desktop, slide-in menu on mobile.
- Time-based welcome on the dashboard; "Shop Now" empty states on dashboard and inventory.
- Other pages load assets/css/no-gradient.css to remove gradients.

Functionality fixes
- Inventory: hero can now return assigned equipment (backend/api/inventory/return.php). Stock is restored.
- Role name: the database role is "enemy". middleware/role-check.php and admin/manage-users (API + page) used "villain", which broke role changes.
- Database connection failure now returns JSON instead of plain text, so pages show a proper error.
- Removed unused/empty endpoints (inventory/request.php, cancel.php) and the test.php / test-session.php debug files.
- Vault / Resource page removed (page, nav links and mentions).
- Notifications: rebuilt page (filters, mark read, mark all, delete, clear read); server now creates notifications on request submit, approve, reject and return (backend/helpers/notify.php).
- Navigation: every hero/user page now has the same links in the same order (Dashboard, Marketplace, Cart, My Requests, Inventory, Notifications, Compatibility, Profile).
- Removed admin links to pages that do not exist (manage-equipment, manage-categories, manage-rules, activity-logs) and the missing aetheryx.css references.

Setup (Laragon)
1. Import database/aetheryx_db_new.sql (your own database export; it creates aetheryx_db_new).
2. Open http://localhost/aetheryx/frontend/public/login.html and sign in with your existing accounts (admin, hero1, jadu1).

Also added
- backend/config/session.php: sessions now use HttpOnly + SameSite=Lax cookies.
- backend/api/admin/activity-logs.php: the admin dashboard activity feed now has an endpoint.
- Readability: larger base text, stronger contrast, 48px buttons, visible keyboard focus, skip link, and a "Text size" button (Normal / Large / Extra large) on dashboard, inventory and notifications.

Database alignment (from aetheryx_db_new.sql)
- compatibility uses (equipment_id, resource_id, compatibility_type, notes); the compatibility API now joins equipment and resources and returns readable names.
- resources uses resource_type (not category); resources/list.php fixed.
- Removed the duplicate compatibility/compatibility.php.

Not verified
- PHP was not available in the review environment, so PHP files were not linted or run against MySQL. Please test in Laragon.

Notification drawer
- assets/js/notification-drawer.js adds a bell with an unread badge on every hero/user page. It opens a right-side panel (All / Unread, mark read, mark all as read, delete, "View all notifications"). Esc or a click outside closes it. Uses the existing notifications API.
