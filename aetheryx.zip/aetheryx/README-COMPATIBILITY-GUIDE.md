# ÆTHERYX Compatibility — User Guide & Functionality

## Sidebar
Compatibility is a primary user navigation item and appears in the same sidebar as Dashboard, Marketplace, Cart, My Requests, Inventory, and Profile. Notifications remain available through the top-right notification control.

## Purpose
Compatibility is a reference tool used before an equipment request. It reads the compatibility records already stored in the MySQL database and shows whether a registered equipment/resource pairing is marked compatible or incompatible.

It does not create a request, change inventory, or invent compatibility decisions.

## User workflow
1. Open **Compatibility** from the sidebar.
2. Search by equipment name, resource name, status, or note.
3. Use the relationship filter to show all, compatible, or incompatible records.
4. Review the equipment/resource pair and the stored notes.
5. If the equipment is relevant, select **View equipment** to open its existing equipment-details page.
6. Continue through the normal marketplace/request flow if the equipment is appropriate and available.

## Functions
- Search compatibility records.
- Filter by compatibility relationship.
- Reset all filters.
- Refresh records from the PHP API.
- Show total, compatible, incompatible, and currently visible counts.
- Show equipment/resource pair names.
- Show notes stored by the system.
- Open the related equipment record.
- Show loading, empty, and API-error states.
- Require an authenticated session through the existing API middleware.

## Status meanings
- **Compatible**: the database records the pairing as compatible.
- **Incompatible**: the database records the pairing as incompatible.

## Database/API behavior
The existing `compatibility` table is used. No new table or database is created.
The page uses `backend/api/compatibility/list.php` and the compatibility API has been aligned with the actual `equipment_id` + `resource_id` + `compatibility_type` schema present in the project SQL.
